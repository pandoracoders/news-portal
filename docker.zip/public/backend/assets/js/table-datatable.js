$(function() {
	"use strict";

    $(document).ready(function() {
        $('#example').DataTable();
      } );


      $(document).ready(function() {
        var table = $('#example2').DataTable( {
            // lengthChange: true,

        } );
    } );


});
