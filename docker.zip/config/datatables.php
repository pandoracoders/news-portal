<?php

return [
    'smart' => true,
    'index_column' => 'ID'
];
