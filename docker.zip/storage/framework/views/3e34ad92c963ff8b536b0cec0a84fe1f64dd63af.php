


<?php $__env->startSection('content'); ?>
    <div class="login-cover-wrapper">
        <div class="card shadow-none">
            <div class="card-body">
                <div class="text-center">
                    <h4>Sign In</h4>
                    <p>Sign In to your account</p>
                </div>
                <form class="form-body row g-3" method="POST" action="<?php echo e(route('post-login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-12">
                        <label for="inputEmail" class="form-label">Email</label>
                        <input type="email"
                            class="form-control <?php echo e(isset($errors) && $errors->has('email') ? 'is-invalid' : ''); ?>"
                            id="inputEmail" name="email">
                        <?php if(isset($errors) && $errors->has('email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12">
                        <label for="inputPassword" class="form-label">Password</label>
                        <input type="password"
                            class="form-control  <?php echo e(isset($errors) && $errors->has('password') ? 'is-invalid' : ''); ?>"
                            id="inputPassword" name="password">

                        <?php if(isset($errors) && $errors->has('password')): ?>
                            <div id="validationServerUsernameFeedback" class="invalid-feedback">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-lg-6">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckRemember"
                                name="remember" value="true">
                            <label class="form-check-label" for="flexSwitchCheckRemember">Remember
                                Me</label>
                            <?php if(isset($errors) && $errors->has('password')): ?>
                                <div id="validationServerUsernameFeedback" class="invalid-feedback">
                                    <?php echo e($errors->first('password')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-12 col-lg-12">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-dark">Sign In</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/auth/pages/login.blade.php ENDPATH**/ ?>