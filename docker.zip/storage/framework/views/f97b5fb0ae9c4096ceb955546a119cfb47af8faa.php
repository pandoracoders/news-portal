


<?php $__env->startPush('styles'); ?>
    <!--plugins-->
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--plugins-->

    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/js/table-datatable.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between mb-2" style="align-items: baseline">
        
        <h6 class="mb-0 text-uppercase">User List</h6>
        
        
        <a href="<?php echo e(route('backend.user-create')); ?>" class="btn btn-primary btn-sm">
            <i class="fa fa-plus"></i>
            Add User
        </a>
        
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="example2" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Alias Name</th>
                            <th>Slug</th>

                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->alias_name); ?></td>
                                <td>
                                    <?php echo e($user->slug); ?>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('backend.user-update_status', $user->id)); ?>"
                                        class="btn btn-sm btn-<?php echo e($user->status == 1 ? 'success' : 'danger'); ?>">
                                        <?php echo e($user->status == 1 ? 'Active' : 'InActive'); ?>

                                    </a>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('backend.user-edit', $user->id)); ?>"
                                        class="btn btn-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(route('backend.user-delete', $user->id)); ?>"
                                        class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Title</th>
                            <th>Slug</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/user/index.blade.php ENDPATH**/ ?>