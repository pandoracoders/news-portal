

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>frontend/css/homepage.css" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Splide('.splide', {
            type: 'loop',
            perPage: 4,
            gap: '5px',
            autoplay: true,
            perMove: 1,
            breakpoints: {

                '820': {
                    perPage: 2,
                    gap: '10px',
                },
                '480': {
                    perPage: 1,
                    gap: '10px'
                }
            }
        }).mount();
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Slider -->

    <main class="container">
        <?php if($data['featured_articles']->count()): ?>
            <?php echo $__env->make('frontend.pages.home.components.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php $__currentLoopData = $data['category_section']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('frontend.pages.home.components.category-section', [
                'section' => $section,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($data['born_today'])): ?>
            <section class="row outer-section">
                <div class="heading mt-4 mb-4">
                    <div class="category-segment">
                        <span>Born Today</span>
                    </div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $data['born_today']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <figure class="textover">
                            <a href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                <img src="<?php echo e(asset($article->image)); ?>" loading="lazy" alt="<?php echo e($article->title); ?>"
                                    class="image_img img-fluid">
                            </a>
                            <figcaption>
                                <a class="text-white" href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                    <?php echo e($article->title); ?>

                                </a>
                            </figcaption>
                            <div class="image_overlay">

                                <p class="image_description">
                                    <?php echo e($article->summary); ?>

                                </p>
                            </div>
                        </figure>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if(count($data['died_today'])): ?>
            <section class="row outer-section">
                <div class="heading mt-4 mb-4">
                    <div class="category-segment">
                        <span>Died Today</span>
                    </div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $data['died_today']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <figure class="textover">
                            <a href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                <img src="<?php echo e(asset($article->image)); ?>" loading="lazy" alt="<?php echo e($article->title); ?>"
                                    class="image_img img-fluid">
                            </a>
                            <figcaption>
                                <a class="text-white" href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                    <?php echo e($article->title); ?>

                                </a>
                            </figcaption>
                            <div class="image_overlay">
                                <p class="image_description">
                                    <?php echo e($article->summary); ?>

                                </p>
                            </div>
                        </figure>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/pages/home/index.blade.php ENDPATH**/ ?>