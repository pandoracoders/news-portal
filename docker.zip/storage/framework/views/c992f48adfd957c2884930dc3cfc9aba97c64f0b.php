<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
            <img src="<?php echo e(asset('backend')); ?>/assets/images/logo-icon-2.png" class="logo-icon" alt="logo icon">
        </div>
        <div>
            <h4 class="logo-text">News Portal</h4>
        </div>
        <div class="toggle-icon ms-auto">
            <ion-icon name="menu-sharp"></ion-icon>
        </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">

        <li>
            <a href="<?php echo e(route('backend.dashboard')); ?>">
                <div class="parent-icon">
                    <i class="bi bi-house-door"></i>
                </div>
                <div class="menu-title">Dashboard</div>
            </a>
        </li>

        <?php $__currentLoopData = config('constants.sidebar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <li class="menu-label"><?php echo e($section['group']); ?></li>

            <?php $__currentLoopData = $section['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(hasPermission($link['url'])): ?>
                    <li <?php echo e(Route::currentRouteName() == $link['url'] ? 'class=mm-active' : ''); ?>>
                        <a href="<?php echo e(route($link['url'])); ?>">
                            <div class="parent-icon">
                                <i class="bi <?php echo e($link['icon']); ?>"></i>
                            </div>
                            <div class="menu-title"><?php echo e($link['title']); ?></div>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(auth()->user()->role->slug == 'super-admin'): ?>
            <li class="menu-label">System</li>

            <li>
                <a href="<?php echo e(route('backend.page-view')); ?>">
                    <div class="parent-icon">
                        <i class="bi bi-file-earmark-break"></i>
                    </div>
                    <div class="menu-title">Page</div>
                </a>
            </li>


            <li <?php echo e(Route::currentRouteName() == 'backend.setting-view' ? 'class=mm-active' : ''); ?>>
                <a href="<?php echo e(route('backend.setting-view', ['type' => 'branding'])); ?>">
                    <div class="parent-icon">
                        <i class="bi bi-gear"></i>
                    </div>
                    <div class="menu-title">Web Setting</div>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('backend.setting-clear_cache')); ?>">
                    <div class="parent-icon">
                        <i class="bi bi-gear"></i>
                    </div>
                    <div class="menu-title">Clear Cache</div>
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <!--end navigation-->
</aside>
<?php /**PATH C:\laragon\www\news-portal\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>