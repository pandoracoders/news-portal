<?php $__env->startPush('styles'); ?>
    <!--plugins-->
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--plugins-->
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/chartjs/chart.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/js/index.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("backend.pages.dashboard.components.card", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("backend.pages.dashboard.components.stat-table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/dashboard/index.blade.php ENDPATH**/ ?>