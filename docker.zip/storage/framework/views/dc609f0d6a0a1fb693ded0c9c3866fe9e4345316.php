


<?php $__env->startPush('styles'); ?>
    <!--plugins-->

    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--plugins-->
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between mb-2" style="align-items: baseline">
        
        <h6 class="mb-0 text-uppercase">Settings </h6>

    </div>

    <?php
    $type = Request()->type;
    ?>


    <div class="card">
        <div class="card-body">
            <ul class="nav nav-tabs nav-primary" role="tablist">

                <?php $__currentLoopData = config('constants.web_setting_tabs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?php echo e($type == $tag ? 'active' : ''); ?>"
                            href="<?php echo e(route('backend.setting-view', ['type' => $tag])); ?>">
                            <div class="d-flex align-items-center">
                                <div class="tab-title">
                                    <?php echo e(unSlug($tag)); ?>

                                </div>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content py-3">
                <div class="tab-pane fade active show mt-2" id="primaryhome" role="tabpanel">
                    <div class="">
                        <form class="row g-3" method="POST"
                            action="<?php echo e(route('backend.setting-update', ['type' => $type])); ?>" enctype="multipart/form-data">
                            <?php echo $__env->make("backend.pages.setting.forms._$type", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/setting/index.blade.php ENDPATH**/ ?>