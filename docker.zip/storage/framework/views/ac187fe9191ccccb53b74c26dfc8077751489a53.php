


<?php $__env->startPush('styles'); ?>
    <!--plugins-->

    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />

    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/input-tags/css/tagsinput.css" rel="stylesheet" />


    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/select2/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/select2/css/select2-bootstrap4.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--plugins-->
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/select2/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    

    <?php echo $__env->make('backend.pages.user.forms._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/user/crud.blade.php ENDPATH**/ ?>