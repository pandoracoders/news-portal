<footer class="footer-section">
    <div class="footer-content pt-3 pb-3">
        <div class="row">
            <div class="col-lg-6 mb-50 d-none d-lg-block">
                <div class="footer-widget">
                    <div class="footer-logo">
                        <h2>
                            <a href="<?php echo e(url("/")); ?>">
                                <?php echo e(getSettingValue('website_title')); ?>

                            </a>
                        </h2>
                    </div>

                </div>
            </div>
            <div class="col-md-6 mb-30 social-section">
                <div class="footer-social-icon">
                    
                    <?php $__empty_1 = true; $__currentLoopData = getSettingType("social-media"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e($media->value); ?>">
                            <i class="fa-brands fa-<?php echo e($media->key); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>


                </div>
            </div>

        </div>
        <div class="row copyright-section mt-3">
            <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                <div class="copyright-text">
                    <p>&copy; Copyright <?php echo e(date('Y')); ?> <a>Pandora Group of Companies</a>. All Right Reserved</p>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <ul>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/layouts/partials/footer.blade.php ENDPATH**/ ?>