<?php
$headers = ['id', 'name', 'status', 'today', 'yesterday', 'this-week', 'last-week', 'this-month', 'last-month'];
$table_data = [];
foreach ($tables as $name => $value) {
    $data_array = [];
    foreach ($value as $key => $user) {
        $data_array[$key]['id'] = $key + 1;
        $data_array[$key]['name'] = $user->name;
        foreach (config('constants.task_status') as $value) {
            $today = $user->getTodayStat($value);
            $yesterday = $user->getYesterdayStat($value);
            $this_week = $user->getThisWeekStat($value);
            $last_week = $user->getLastWeekStat($value);
            $this_month = $user->getThisMonthStat($value);
            $last_month = $user->getLastMonthStat($value);
            if ($today == 0 && $yesterday == 0 && $this_week == 0 && $last_week == 0 && $this_month == 0 && $last_month == 0) {
                // $data_array[$key]['status'][$value] = [];
            } else {
                $data_array[$key]['status'][$value] = [
                    'today' => $today,
                    'yesterday' => $yesterday,
                    'this-week' => $this_week,
                    'last-week' => $last_week,
                    'this-month' => $this_month,
                    'last-month' => $last_month,
                ];
            }
        }
    }
    $table_data[$name] = $data_array;
}

?>


<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs nav-primary" role="tablist">
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $table_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data): ?>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?php echo e($count == 0 ? 'active' : ''); ?>" data-bs-toggle="tab"
                            href="#<?php echo e($key); ?>" role="tab" aria-selected="true">
                            <div class="d-flex align-items-center">
                                <div class="tab-title"><?php echo e(ucwords($key)); ?></div>
                            </div>
                        </a>
                    </li>
                    <?php
                        $count++;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <div class="tab-content py-3">
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $table_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data): ?>
                    <div class="tab-pane fade <?php echo e($count == 0 ? 'show active' : ''); ?>" id="<?php echo e($key); ?>"
                        role="tabpanel">
                        <div class="card radius-10 w-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <h6 class="mb-0"><?php echo e(ucwords($key)); ?> Stats</h6>
                                </div>
                                <div class="table-responsive mt-2">
                                    <table class="table align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th class="text-center">
                                                        <?php echo e(unSlug($header)); ?>

                                                    </th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td> <?php echo e($arr['id']); ?></td>
                                                    <td> <?php echo e($arr['name']); ?></td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e(unSlug($status)); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['today'] ? $value['today'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['yesterday'] ? $value['yesterday'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['this-week'] ? $value['this-week'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['last-week'] ? $value['last-week'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['this-month'] ? $value['this-month'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table class="table align-middle mb-0">
                                                            <thead class="table-light">
                                                                <?php $__currentLoopData = $arr['status'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th class="text-center">
                                                                            <?php echo e($value['last-month'] ? $value['last-month'] : '-'); ?>

                                                                        </th>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </thead>
                                                        </table>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        $count++;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/dashboard/components/stat-table.blade.php ENDPATH**/ ?>