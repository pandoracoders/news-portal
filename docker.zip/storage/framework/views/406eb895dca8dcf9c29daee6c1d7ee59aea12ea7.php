<div class="row similar-post-container">
    <?php $__currentLoopData = $article->more(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-3 post-section">
            <div class="similar-post">
                <div class="image">
                    <figure class="m-0">
                        <a href="<?php echo e(route('singleArticle', $article->slug)); ?>">
                            <img src="<?php echo e(asset($article->image)); ?>" alt="<?php echo e($article->title); ?>"
                                class="image_img img-fluid">
                        </a>
                    </figure>
                </div>
                <div class="similar-post-title">
                    <div class="title">
                        <a href="<?php echo e(route('singleArticle', $article->slug)); ?>"> <?php echo e($article->title); ?></a>
                    </div>
                    <div class="meta">
                        <p class="article-date"> <?php echo e(dateFormat($article->published_at)); ?> | </p>
                        <p class="article-author">
                            <a href="<?php echo e(route('authorArticle', $article->writer->slug)); ?>">
                                <?php echo e($article->writer->alias_name); ?>

                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/pages/article/components/more.blade.php ENDPATH**/ ?>