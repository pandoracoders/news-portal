<div class="row">
    <?php $__currentLoopData = $article->youMayAlsoLike(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="sidebar-post col-md-6 col-lg-12 mt-3">
            <div class="image">
                <figure class="m-0">
                    <a href="<?php echo e(route('singleArticle', $article->slug)); ?>">
                        <img src="<?php echo e(asset($article->image)); ?>" alt="<?php echo e($article->title); ?>" class="image_img img-fluid">
                    </a>
                </figure>
            </div>
            <div class="sidebar-post-title mx-2">

                <h2 class="title">
                    <a href="<?php echo e(route('singleArticle', $article->slug)); ?>">
                        <?php echo e($article->title); ?>

                    </a>
                </h2>
                <div class="meta">
                    <span class="article-date"><?php echo e(dateFormat($article->published_at)); ?> | </span><span class="article-author"><a href="<?php echo e(route('authorArticle', $article->author->slug)); ?>">
                        <?php echo e($article->author->alias_name); ?></a></span>
               </div>

            </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/pages/article/components/sidebar.blade.php ENDPATH**/ ?>