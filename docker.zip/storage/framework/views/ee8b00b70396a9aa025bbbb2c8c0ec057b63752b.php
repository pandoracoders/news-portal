<div class="tags">
    <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="single-tag">
            <a href="<?php echo e(route('tags', $tag->slug)); ?>"># <?php echo e($tag->original_title); ?></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/pages/article/components/tags.blade.php ENDPATH**/ ?>