 <!-- Biography Section -->
 <section class="row outer-section">
     <div class="col-lg-8 mt-4">
         <div class="heading">
             <div class="category-segment">
                 <span><?php echo e($section['category']->title); ?></span>
             </div>
         </div>
         <div class="row">
             <div class="biography-left col-lg-6">
                <div class="row mt-3">
                    <?php $__empty_1 = true; $__currentLoopData = $section['articles'][0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-12">
                        <div class="biography-single">
                            <div class="col-4 image">
                                <figure class="m-0">
                                    <a href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                        <img src="<?php echo e(asset($article->image)); ?>" loading="lazy"
                                            alt="<?php echo e($article->title); ?>" class="image_img img-fluid">
                                    </a>
                                </figure>
                            </div>
                            <div class="col-8 biography-title">
                                
                                <h2>
                                    <a href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                        <?php echo e($article->title); ?>

                                    </a>
                                </h2>

                                <div class="meta">
                                    <p class="article-date"><?php echo e(carbon($article->published_at)->format('M d, Y')); ?> | </p> <a
                                         href="<?php echo e(route('authorArticle', ['author' => $article->writer->slug])); ?>"><p
                                         class="article-author">
                                         <?php echo e($article->writer->alias_name); ?>

                                        </p>   
                                    </a>
                                 </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </div>
             </div>

             <div class="biography-right col-lg-6 mt-3">
                 <?php $__currentLoopData = $section['articles'][1] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <figure class="textover">
                         <img src="<?php echo e(asset($article->image)); ?>" loading="lazy" alt="<?php echo e($article->title); ?>"
                             class="image_img img-fluid">
                         <figcaption>
                             <a class="text-white" href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                 <?php echo e($article->title); ?>

                             </a>
                         </figcaption>
                     </figure>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         </div>
         <div class="row">
             <div class="col-12">
                 <h2 class="text-center load">
                     <a href="<?php echo e(route('singleArticle', ['slug' => $section['category']->slug])); ?>" class="btn">View
                         All</a>
                 </h2>
             </div>
         </div>
     </div>
     <!-- Trending Section -->
     <div class="col-lg-4 mt-4">
         <div class="heading">
             <div class="category-segment">
                 <span><?php echo e($section['second']['title']); ?></span>
             </div>
         </div>
         <div class="trending mt-3">
             <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $section["second"]["articles"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <div class="trending-single col-md-6 col-lg-12">
                     <div class="image">
                         <figure class="m-0">
                             <a href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                 <img src="<?php echo e(asset($article->image)); ?>" loading="lazy" alt="<?php echo e($article->title); ?>"
                                     class="image_img img-fluid">
                             </a>
                         </figure>
                     </div>
                     <div class="trending-title">
                         <h2>
                             <a class="" href="<?php echo e(route('singleArticle', ['slug' => $article->slug])); ?>">
                                 <?php echo e($article->title); ?>

                             </a>
                         </h2>
                         <div class="meta">
                            <p class="article-date"><?php echo e(carbon($article->published_at)->format('M d, Y')); ?> | </p> <a
                                 href="<?php echo e(route('authorArticle', ['author' => $article->writer->slug])); ?>"><p
                                 class="article-author">
                                 <?php echo e($article->writer->alias_name); ?>

                                </p>   
                            </a>
                         </div>
                     </div>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
             <?php endif; ?>
             </div>
         </div>
     </div>
 </section>
<?php /**PATH C:\laragon\www\news-portal\resources\views/frontend/pages/home/components/category-section.blade.php ENDPATH**/ ?>