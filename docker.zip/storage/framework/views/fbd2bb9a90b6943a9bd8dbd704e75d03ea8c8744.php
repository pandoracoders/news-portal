

<?php echo $__env->make('backend.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('styles'); ?>
    <!--plugins-->
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--plugins-->

    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/js/table-datatable.js"></script>

    <?php echo e($dataTable->scripts()); ?>



    <script>
        $(document).ready(function() {
            window.table = window.LaravelDataTables[Object.keys(window.LaravelDataTables)[0]];

        });



        $(document).on("change", ".table-filter", function() {
            window.table.ajax.url(window.location.href + "?" + $(this).serialize()).load();
            // window.table.ajax.reload();
        })
    </script>
<?php $__env->stopPush(); ?>


<?php
$tabs = [...['all'], ...config('constants.task_status')];
if (in_array(auth()->user()->role->title, ['Editor', 'Super Admin'])) {
    $tabs = array_diff($tabs, ['writing']);
}
?>


<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between mb-2" style="align-items: baseline">
        
        <h6 class="mb-0 text-uppercase">Article List</h6>
        
        
        
        
    </div>


    <div class="card">
        <div class="card-body">
            <ul class="nav nav-tabs nav-primary" role="tablist">

                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item" role="presentation">
                        <?php if(Request()->task_status): ?>
                            <a class="nav-link <?php echo e(Request()->task_status == $task ? 'active' : ''); ?>"
                                href="<?php echo e(route('backend.article-view', ['task_status' => $task == 'all' ? '' : $task])); ?>">
                                <div class="d-flex align-items-center">
                                    <div class="tab-title">
                                        <?php echo e($task == 'submitted' ? ucwords($task) . ' (Open for editor)' : ucwords($task)); ?>

                                    </div>
                                </div>
                            </a>
                        <?php else: ?>
                            <a class="nav-link <?php echo e($key == 0 ? 'active' : ''); ?>"
                                href="<?php echo e(route('backend.article-view', ['task_status' => $task == 'all' ? '' : $task])); ?>">
                                <div class="d-flex align-items-center">
                                    <div class="tab-title">
                                        <?php echo e($task == 'submitted' ? ucwords($task) . ' (Open for editor)' : ucwords($task)); ?>

                                    </div>
                                </div>
                            </a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content py-3">
                <div class="tab-pane fade active show" id="primaryhome" role="tabpanel">
                    <div class="table-responsive">
                        <?php echo e($dataTable->table()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\news-portal\resources\views/backend/pages/article/index.blade.php ENDPATH**/ ?>