<div class="modal fade show" id="exampleVerticallycenteredModal" tabindex="-1" style="display: block;" aria-modal="true"
    role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Message</h5>
            </div>
            <div class="modal-body">
                <div class="col-12 mb-2">
                    <textarea name="summary" class="form-control" rows="5" name="message"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Saveclear</button>
            </div>
        </div>
    </div>
</div>
