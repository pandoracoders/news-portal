<meta name="description" content="">
<meta name="theme-color" content="#db3434">
<meta name="msapplication-navbutton-color" content="#db3434">
<meta name="apple-mobile-web-app-status-bar-style" content="#db3434">
<meta name="article:author" content="">
<meta name="article:published_time" content="">
<meta property="og:site_name" content="">
<meta property="og:type" content="">
<meta property="og:title" content="">
<meta property="og:article:published_time" content="">
<meta property="og:description" content="">
<meta property="og:image" content="">
<meta property="og:image:alt" content="">
<meta property="twitter:title" content="">
<meta property="twitter:description" content="">
<meta property="twitter:domain" content="{{ getSettingValue('website_title') }}">
<meta property="twitter:image" content="">
<link href="{{ Request::url() }}" rel="canonical">
